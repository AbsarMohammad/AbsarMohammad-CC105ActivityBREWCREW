package com.example.brew_crew

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
